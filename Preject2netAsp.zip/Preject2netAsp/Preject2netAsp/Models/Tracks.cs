﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Preject2netAsp.Models
{
    public class Tracks
    {
        public string Id { get; set; }
        public string Position { get; set; }
        public string Name { get; set; }
        public string Duration { get; set; }
        public string License_ccurl { get; set; }
        public string Audio { get; set; }
        public string Audiodownload { get; set; }
    }
}
