﻿using System;
using System.Collections.Generic;

namespace Preject2netAsp.Models
{
    public partial class Friend
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string EmailFriends { get; set; }
    }
}
