﻿using System;

namespace Preject2netAsp.Models
{
    internal class IndexAttribute : Attribute
    {
    }
}